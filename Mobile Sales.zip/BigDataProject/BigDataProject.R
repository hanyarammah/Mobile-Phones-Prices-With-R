#Libraries used
library(tidyverse)
library(dplyr)
library(ggplot2)
library(caret)
library(car)

#Read Data
df= read.csv("E://Hanya//OneDrive//Desktop//BigDataProject//laptops.csv")
print(head(df, n=10))

#Print Data Statistics
summary(df)

#Prints Data types
str(df)

#Rows & Columns Number
cat('Number of Rows:',nrow(df),'   ','Number of Fields:',ncol(df))

#Sum of nulls
colSums(is.na(df))

#Check for duplicates using duplicated function
duplicates <- df[duplicated(df), ]
if (nrow(duplicates) > 0) {
  print("There are duplicate rows in your data frame.")
} else {
  print("No duplicate rows found.")
}

#n0: There is no difference in final price between touch and non-touch screened laptops.

#check if normally distributed to prepare and decide which hypothesis test technique to use

#Final Price Distribution
density_plot <- density(df$Final.Price)
plot(density_plot, main = "Final Price Distribution", xlab = "Final Price", ylab = "Density",mar = c(1, 1, 1, 1))

#Observation: Data is skewed to the right and is not in a normal distribution form

#Touch and non-touch screen distribution
ggplot(df, aes(x = Touch, y = Final.Price)) +
  geom_boxplot(aes(fill = Touch)) +
  labs(title = "Touch Screen Analysis", x = "Touchscreen", y = "Final Price")

#Observation: There is a significant difference between laptops with and without touch screens
              #in terms of price and statistical distribution.

# Separate data based on Touchscreen
touch_data <- df[df$Touch == "Yes",]$Final.Price  # Filter for Touchscreen laptops
non_touch_data <- df[df$Touch == "No",]$Final.Price  # Filter for Non-touchscreen laptops

# Calculate variance for each group
touch_variance <- var(touch_data)
non_touch_variance <- var(non_touch_data)

# Print the variances
cat("Variance (Touchscreen):", touch_variance, "\n")
cat("Variance (Non-touchscreen):", non_touch_variance)

#Observation: non equal variances between the two group, exclude the student t-test method.

dev.off()

#Observation: Since variance is non equal between two groups, we should exclude student t-test,
              #Since data is not normally distributed, we should exclude welch t-test

#Use Wilcoxon Rank Sum Test since it is the most suitable

wilcox.test(df$Final.Price ~ df$Touch)

#Observation:very small p value, reject null hypothesis, there's a difference between
            # touch and non-touch laptops

#visualization and data exploration:

#Distribution of Storage
counts <- table(df$Storage)
colors <- rainbow(length(counts)) 
barplot(counts,main = "Distribution of Storage",col = colors[1:length(counts)])

#Observation: most laptops had storage equivalent to 512,followed by 1000, followed by 256
             #and least numbers of storage were 240 and 32

#How is final price influenced by storage?
ggplot(df, aes(x = df$Storage, y = Final.Price,plot.width = 20)) +
  geom_point(pch = 19, color = "green", position = position_jitter(width = 0.1)) +
  labs(x = "Storage", y = "Final Price", title = "Final Price by Storage")

#Observation: There are laptops with storage of 250 and 500 that are similar in price 
              #to storage of 2000, which implies that the storage is not the only influence
              # to the price.

#Status Distribution
counts1 <- table(df$Status)
barplot(counts1,main = "Status Difference",col = rainbow(length(counts1)))

#Observation:Number of new laptops was much higher than the refurbished.

#How does screen size affect final price?
ggplot(df, aes(x = df$Screen, y = df$Final.Price)) +
  geom_point(color = "purple") +
labs(x = "Screen Size (inches)", y = "Final Price")

#Observation: starting from laptops with screen sizes >13 inches, final price has noticeably risen

#Distribution of RAM sizes

ram_sizes <- df$RAM
ram_size_counts <- table(ram_sizes) #count each size
pct <- round(ram_size_counts / sum(ram_size_counts) * 100, 1) #calc percentage
pie_labels <- paste(names(ram_size_counts), paste0(" (", pct, "%)"), sep="") #add labels
pie_values <- as.numeric(ram_size_counts) #get values
pie(pie_values, labels = pie_labels, col = rainbow(length(pie_labels)), 
    main = "Distribution of RAM Sizes in Laptops",cex = 0.7)
#Observation: Most laptops had RAMs equivalent to 16 GBs.

#How does RAM sizes affect final price?

ggplot(df, aes(x = RAM, y = Final.Price)) +
  geom_point(color = "red") +  
  labs(title = "Final Price vs RAM", 
       x = "RAM (GB)",
       y = "Final Price") +
  theme_bw()
#Observation: Some laptops with 8 GB, 16 GB, and 64 GB have approximately the same final price
              #which indicates that its not the only influence on final price.

#Machine learning and predictions:

#70% for training
split_ratio <- 0.7

# Randomly sample rows for the training
train_index <- sample(1:nrow(df), size = nrow(df) * split_ratio)

train_data <- df[train_index, ]
test_data <- df[-train_index, ]

#Linear regression model
model<- lm(df$Final.Price ~ df$Status + df$Brand + df$Model + df$CPU + df$RAM + df$Storage + df$Storage.type + df$Screen + df$Touch, data = df)
summary(model)

#Saving R squared value

r_sq_0 <- summary(model)$r.squared
cat("R-squared of train:", r_sq_0, "\n")


prediction <- predict(model, newdata = test_data)
mse <- mean((test_data$Final.Price - prediction)^2)
cat("Mean Squared Error:", mse, "\n")
mae <- mean(abs(test_data$Final.Price - prediction))
cat("Mean Absolute Error:", mae, "\n")

 #observation: The model shows a good fit based on R squared, an RSE of 399 shows that the
              #predicted and actual values were close, MSE and MAE are average considering
              #the scale of the target variable being high

 #Predicted vs Actual plot
 
 ggplot(df, aes(x = prediction, y = Final.Price)) +
   geom_point(aes(alpha = 0.5)) + 
   geom_abline(color = "red") +
   labs(title = "Predicted vs. Actual Final Price", x = "Predicted Price", y = "Actual Final Price") +
   theme_classic() 
 
 
 